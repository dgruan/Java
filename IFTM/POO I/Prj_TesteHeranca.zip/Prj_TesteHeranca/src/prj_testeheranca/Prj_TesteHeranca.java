package prj_testeheranca;

import prj_testeheranca.DadosEntrada.Gerente;
import prj_testeheranca.DadosEntrada.Vendedor;
import java.util.Scanner;
        
public class Prj_TesteHeranca {

    public static void main(String[] args) {
        
        String nome;
        double salario, comissao;
        String setor;
        
        Scanner sc = new Scanner(System.in);
        Gerente g1 = new Gerente();
        Vendedor v1 = new Vendedor();
        
        //setters
        System.out.println("Gerente");
        System.out.print("Nome: ");
        nome = sc.nextLine();
        System.out.print("Salário: ");
        salario = sc.nextDouble();
        System.out.print("Setor: ");
        setor = sc.nextLine();
        
        g1.setNome(nome);
        g1.setSalario(salario);
        g1.setSetor(setor);
        
        System.out.println("Vendedor");
        System.out.print("Nome: ");
        nome = sc.nextLine();
        System.out.print("Salário: ");
        salario = sc.nextDouble();
        System.out.print("Comissão: ");
        comissao = sc.nextDouble();
        
        v1.setNome(nome);
        v1.setSalario(salario);
        v1.setComissao(comissao);
        
        //getters
        System.out.println("Gerente");
        System.out.println("Nome: " + g1.getNome());
        System.out.println("Salário: " + g1.getSalario());
        System.out.println("Setor: " + g1.getSetor());
        
        System.out.println("Vendedor");
        System.out.println("Nome: " + v1.getNome());
        System.out.println("Salário: " + v1.getSalario());
        System.out.println("Comissão: " + v1.getComissao());
    }
    
}

package application;
import models.DadosEntradaIMC;
import models.DadosSaidaIMC;
import bo.CalculadoraIMC;

import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        DadosEntradaIMC de = new DadosEntradaIMC();
        
        double peso;
        double altura;
        
        System.out.print("Peso: ");
        peso = sc.nextDouble();
        
        System.out.print("Altura: ");
        altura = sc.nextDouble();
        
        de.setPeso(peso);
        de.setAltura(altura);
        
        DadosSaidaIMC s = new DadosSaidaIMC();
        CalculadoraIMC calc = new CalculadoraIMC();
        
        calc.calcular(de, s);
        
        System.out.println("IMC = " + s.getResultadoImc());

    }
    
}

package models;

public class DadosSaidaIMC {
    private double resultadoImc;
    
    public void setResultadoImc(double resultadoImc) {
        this.resultadoImc = resultadoImc;
    }
    
    public double getResultadoImc() {
        return resultadoImc;
    }
}

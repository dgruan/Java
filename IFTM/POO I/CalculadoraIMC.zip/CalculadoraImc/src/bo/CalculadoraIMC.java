package bo;
import models.DadosEntradaIMC;
import models.DadosSaidaIMC;

public class CalculadoraIMC {
    
    public void calcular(DadosEntradaIMC de, DadosSaidaIMC s) {
        
        double peso = de.getPeso();
        double altura = de.getAltura();
        
        double resultado = peso / (altura * altura);
        
        s.setResultadoImc(resultado);
    }
}

package bo;
import models.DadosSaidaRetangulo;
import models.DadosEntradaRetangulo;

public class CalculadoraRetangulo {
    
    DadosSaidaRetangulo ds = new DadosSaidaRetangulo();

    public DadosSaidaRetangulo calcularArea(DadosEntradaRetangulo de) {
        
        double base = de.getBase();
        double altura = de.getAltura();
        
        double resultado = base * altura;
        
        ds.setArea(resultado);
        
        return ds;
    }
    
    public DadosSaidaRetangulo calcularPerimetro(DadosEntradaRetangulo de) {
        double base = de.getBase();
        double altura = de.getAltura();
        
        double resultado = 2 * (base + altura);
        
        ds.setPerimetro(resultado);
        
        return ds;
    }

}

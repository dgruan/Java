package application;

import models.DadosEntradaRetangulo;
import models.DadosSaidaRetangulo;
import java.util.Scanner;
import bo.CalculadoraRetangulo;

public class Main {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        DadosEntradaRetangulo de = new DadosEntradaRetangulo();
        CalculadoraRetangulo calc = new CalculadoraRetangulo();
        
        double base;
        double altura;
        
        System.out.print("Base: ");
        base = sc.nextDouble();
        
        System.out.print("Altura: ");
        altura = sc.nextDouble();
        
        de.setBase(base);
        de.setAltura(altura);
        
        DadosSaidaRetangulo ds = calc.calcularArea(de);
        ds = calc.calcularPerimetro(de);
        
        System.out.println("Area = " + ds.getArea());
        System.out.println("Perimetro = " + ds.getPerimetro());
    }
    
}

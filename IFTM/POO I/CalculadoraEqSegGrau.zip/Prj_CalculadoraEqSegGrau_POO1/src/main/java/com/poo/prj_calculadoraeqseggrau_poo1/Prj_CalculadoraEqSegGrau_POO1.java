/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poo.prj_calculadoraeqseggrau_poo1;

import com.poo.prj_calculadoraeqseggrau_poo1.bo.CalculoEqSegGrau;
import com.poo.prj_calculadoraeqseggrau_poo1.bo.CalculoEqSegGrau_2;
import com.poo.prj_calculadoraeqseggrau_poo1.models.DadosEntrada;
import com.poo.prj_calculadoraeqseggrau_poo1.models.DadosSaida;

/**
 *
 * @author user
 */
public class Prj_CalculadoraEqSegGrau_POO1 {

    public static void main(String[] args) {
        
        /*DadosEntrada de = new DadosEntrada();
        
        de.setA(1);
        de.setB(5);
        de.setC(6);
        
        CalculoEqSegGrau esg = new CalculoEqSegGrau();
        
        DadosSaida ds;
        esg.calcularDelta(de);
        esg.calcularX1L(de);
        esg.calcularX2L(de);
        esg.calcularXv(de);
        ds = esg.calcularYv(de);*/
        
        DadosEntrada de = new DadosEntrada();
        
        de.setA(1);
        de.setB(5);
        de.setC(6);
        
        de.setA(1);
        
        CalculoEqSegGrau_2 esg = new CalculoEqSegGrau_2();        
        DadosSaida ds = new DadosSaida();
        
        esg.calcularDelta(de, ds);
        esg.calcularX1L(de, ds);
        esg.calcularX2L(de, ds);
        esg.calcularXv(de, ds);
        esg.calcularYv(de, ds);
        
        
        System.out.println("Delta: "+ds.getDelta());
        System.out.println("x': "+ds.getX1L());
        System.out.println("x'': "+ds.getX2L());
        System.out.println("xV: "+ds.getxV());
        System.out.println("yV: "+ds.getyV());
    }
}
